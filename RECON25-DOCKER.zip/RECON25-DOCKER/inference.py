import os
from os.path import join
import sys
import pathlib
sys.path.insert(0, os.path.dirname(os.path.dirname(pathlib.Path(__file__).parent.absolute())))
import re
import argparse
import scipy
import glob
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import torch
from torch.utils.data import DataLoader

import fastmri.data.transforms as T

import time

# from models.genmodel import Generator

from promptmr_v2 import PromptMR

from utils import crop_submission, load_kdata, loadmat 
from utils import count_parameters, count_trainable_parameters, count_untrainable_parameters


def get_adj_frames_indices(dataslice, num_slices_in_volume, num_t_in_volume=None, isT2=False):
    '''
    when we reshape t, z to one axis in preprocessing, we need to get the indices of the slices in the original t, z axis;
    then find the adjacent slices in the original z axis
    '''
    ti = dataslice//num_slices_in_volume
    zi = dataslice - ti*num_slices_in_volume

    zi_idx_list = [zi]

    if isT2: # only 3 nw in T2, so we repeat adjacent for 3 times
        ti_idx_list = [ (i+ti)%num_t_in_volume for i in range(-1,2)]
        ti_idx_list = 1*ti_idx_list[0:1] + ti_idx_list + ti_idx_list[2:3]*1
    else:
        ti_idx_list = [ (i+ti)%num_t_in_volume for i in range(-2,3)]

    # print(ti_idx_list,zi_idx_list)
    output_list = []

    for zz in zi_idx_list:
        for tt in ti_idx_list:
            output_list.append(tt*num_slices_in_volume + zz)

    return output_list, ti_idx_list


num_adj_slices = 5
start_adj, end_adj = -(num_adj_slices//2), num_adj_slices//2+1
def _get_ti_adj_idx_list(ti, num_t_in_volume, start_adj, end_adj):
    '''
    Get the circular adjacent indices of the temporal axis for the given ti.
    '''
    start_lim, end_lim = -(num_t_in_volume // 2), (num_t_in_volume // 2 + 1)
    start, end = max(start_adj, start_lim), min(end_adj, end_lim)
    
    # Generate initial list of indices
    ti_idx_list = [(i + ti) % num_t_in_volume for i in range(start, end)]
    
    # Duplicate padding if necessary
    replication_prefix = max(start_lim - start_adj, 0) * ti_idx_list[0:1]
    replication_suffix = max(end_adj - end_lim, 0) * ti_idx_list[-1:]
    
    return replication_prefix + ti_idx_list + replication_suffix


class class_dataset(torch.utils.data.Dataset):
    def __init__(self, fname):
        self.fname = fname


        # Retry loading kspace
        while True:
            try:
                self.kspace = load_kdata(fname)
                break
            except Exception as e:
                print(f"[Retrying] Error reading kspace file {fname}: {e}")
                time.sleep(1)

        # Retry loading mask
        mask_path = fname.replace('UnderSample_TaskR', 'Mask_TaskR').replace('kus', 'mask')
        while True:
            try:
                self.mask = loadmat(mask_path)
                break
            except Exception as e:
                print(f"[Retrying] Error reading mask file {mask_path}: {e}")
                time.sleep(1)


        self.mask = self.mask[list(self.mask.keys())[0]]

        #3 dims data types!
        if self.kspace.ndim == 3:
            print("*************************$$$$$$$$$$$$$$$$$$$$$$$$$$$*********************")
            self.kspace = np.expand_dims(self.kspace, axis=0)

        #4 dims data types!
        if self.kspace.ndim == 4:
            print("*********************$$$$$$$4444$$$$$$$*********************:", fname)
            self.kspace = np.expand_dims(self.kspace, axis=0)
            self.mask = np.expand_dims(self.mask, axis=0)
            self.added_extra_dim = True


        self.num_t = self.kspace.shape[0]
        self.num_slices = self.kspace.shape[1]
        self.num_c = self.kspace.shape[2]


        self.kspace = self.kspace.reshape(-1, self.kspace.shape[2], self.kspace.shape[3], self.kspace.shape[4]).transpose(0, 1, 3, 2)
        self.mask = self.mask.transpose(0, 2, 1)


        self.num_files = self.kspace.shape[0]
        self.ist2 = 1 if 'T2' in fname else 0
        self.maskfunc = None

    def __getitem__(self, dataslice):

        slice_idx_list, ti_idx_list = get_adj_frames_indices(dataslice, self.num_slices, self.num_t, isT2=self.ist2)

        _input = []
        for slc_i in slice_idx_list:
            _input.append(self.kspace[slc_i])

        _mask = []
        for t_i in ti_idx_list:
            _mask.append(self.mask[t_i])
              
        _input = np.concatenate(_input, axis=0) #.transpose(0,2,1)
        kspace_torch = torch.from_numpy(np.stack((_input.real, _input.imag), axis=-1).astype(np.float32))
        masked_kspace = kspace_torch


        # Assume each mask is 2D: (440, 198)
        # Assume mask is 2D, e.g., shape (H, W)
        _mask = [np.stack((mask, mask), axis=-1) for mask in _mask]  # Result: (H, W, 2)


        # Repeat along channel axis (axis 0) -> (self.num_c, 440, 198, 2)
        _mask = [np.tile(mask[None, ...], (self.num_c, 1, 1, 1)) for mask in _mask]


        # _mask = [np.tile(mask[None, :, :], (self.num_c, 1, 1)) for mask in _mask]
        mask = np.concatenate(_mask, axis=0) #.transpose(0,2,1)
    
        mask_torch = torch.from_numpy(mask.astype(np.float32))
        mask_torch = mask_torch.to(torch.bool)


        return masked_kspace, mask_torch, dataslice

    def __len__(self):
        return self.num_files
    

def predict(f, model, bs1 = 1, center_crop=False, num_works = 2, input_dir='', output_dir=''):

    print(f'model:\ntotal param: {count_parameters(model)}\ntrainable param: {count_trainable_parameters(model)}\nuntrainable param: {count_untrainable_parameters(model)}\n##############')
    device = 'cuda:0'

    with torch.no_grad():
        for ff in tqdm(f, desc='files'):
            print('-- processing --', ff)

            dataset = class_dataset(ff)
            dataloader = DataLoader(dataset, batch_size=bs1, shuffle=False, num_workers=num_works, pin_memory=True, drop_last=False)
            gen_pred = []
                
            for masked_kspace, mask, dataslice in tqdm(dataloader, desc='Processing'):
                
                bs = masked_kspace.shape[0]


                if any(x in ff for x in ["Uniform", "ktUniform", "ktGaussian"]):
                    mask_type = "cartesian"
                elif "ktRadial" in ff:
                    mask_type = "kt_radial"


#                print(masked_kspace.shape)
                output = model(masked_kspace = masked_kspace.to(device), mask = mask.to(device), num_low_frequencies = torch.tensor(16), mask_type= mask_type)
                
                img_pred = output['img_pred']
#                print(img_pred.shape)

                img_zf = output['img_zf']
                sens_maps = output['sens_maps']

                output = img_pred

                for i in range(bs):
                    gen_pred.append((dataslice[i],output[i:i+1]))
        
            gen_pred = torch.cat([out for _,out in sorted(gen_pred)], dim=0).cpu()
            gen_pred = gen_pred.cpu().numpy().transpose(0, 2, 1).reshape(dataset.num_t, dataset.num_slices, gen_pred.shape[2], gen_pred.shape[1])


            save_path = ff.replace(input_dir, join(output_dir, 'TaskR1/MultiCoil'))
            # TaskR1\MultiCoil\Mapping\ValidationSet\UnderSample_TaskR1\Center001\UIH_30T_umr780\P007\T1map_kus_ktRadial16.mat
            # save_path = ff.replace(input_dir, output_dir)

            save_dir = os.path.dirname(save_path)
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)

            save_mat = gen_pred.transpose(3,2,1,0) # x,y,z,t for submission
            

            if center_crop:
                save_mat = crop_submission(save_mat, ff)

            # Squeeze back if extra dim was added during dataset construction
            if getattr(dataset, 'added_extra_dim', False):
                # print("squeezeddd!!!!")
                save_mat = save_mat.squeeze()

            # # print("FINAL SHAPE: ", save_mat.shape)
            scipy.io.savemat(save_path, {'img4ranking':save_mat})
            print('-- saving --', save_path)


if __name__ == '__main__':
    argv = sys.argv
    parser = argparse.ArgumentParser()

    # parser.add_argument('--input', type=str, nargs='?', default='/input', help='input directory')
    parser.add_argument('--input', type=str, nargs='?', default='input/', help='input directory')
    parser.add_argument('--output', type=str, nargs='?', default='', help='output directory')
    parser.add_argument('--center_crop', action='store_true', default=True, help='Enable center cropping for validation leaderboard submission')
    parser.add_argument('--evaluate_set', type=str, choices=["ValidationSet", "TestSet"], help='Choose the evaluation set: ValidationSet or TestSet')
    parser.add_argument('--batch_size', type=int, default=3, help='Batch size for the model.')
    parser.add_argument('--num_works', type=int, default=1, help='num of processors to load data.')


    args = parser.parse_args() 
    input_dir = args.input
    output_dir = args.output
    center_crop = args.center_crop
    evaluate_set = 'TestSet'
    bs1 = args.batch_size
    num_works = args.num_works

    if os.name != 'nt':
        pathlib.WindowsPath = pathlib.PosixPath
        print("pathlib.WindowsPat: ", pathlib.WindowsPath)
    
    print("Input data store in:", input_dir)
    print("Output data store in:", output_dir)

    def print_tree(startpath, max_level=3):
        for root, dirs, files in os.walk(startpath):
            level = root.replace(startpath, '').count(os.sep)
            if level >= max_level:
                continue
            indent = ' ' * 4 * level
            print(f"{indent}{os.path.basename(root)}/")
            subindent = ' ' * 4 * (level + 1)
            for f in files:
                print(f"{subindent}{f}")


    print("\n######## Directory Tree ########")
    print_tree(input_dir, max_level=3)  # change max_level for depth
    print("################################")

    ############################################################# 4X:


    import os
    files = []
    for root, directories, filenames in os.walk(input_dir):
        for filename in filenames:
             files.append(os.path.join(root, filename))


# Filtering patterns

    f_cine = sorted([
        file for file in files
        if "Cine" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_mapping = sorted([
        file for file in files
        if "Mapping" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_t1rho = sorted([
        file for file in files
        if "T1rho" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_blackblood = sorted([
        file for file in files
        if "BlackBlood" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_flow2d = sorted([
        file for file in files
        if "Flow2d" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_lge = sorted([
        file for file in files
        if "LGE" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_perfusion = sorted([
        file for file in files
        if "Perfusion" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_t1w = sorted([
        file for file in files
        if "T1w" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])
    f_t2w = sorted([
        file for file in files
        if "T2w" in file and "UnderSample_Task" in file and file.endswith(".mat")
    ])


    f = f_cine + f_mapping + f_t1rho + f_blackblood + f_flow2d + f_lge + f_perfusion + f_t1w + f_t2w


    print("##############")
    print(f"Cine       : {len(f_cine)}")
    print(f"Mapping    : {len(f_mapping)}")
    print(f"T1rho      : {len(f_t1rho)}")
    print(f"Flow2d     : {len(f_flow2d)}")
    print(f"BlackBlood : {len(f_blackblood)}")
    print(f"LGE        : {len(f_lge)}")
    print(f"Perfusion  : {len(f_perfusion)}")
    print(f"T1w        : {len(f_t1w)}")
    print(f"T2w        : {len(f_t2w)}")
    print(f"Total files: {len(f)}")
    print("##############")


################################################################## MODEL ##################################################################


### NEW
    model = PromptMR(      
        num_cascades= 16,
        num_adj_slices= 5,
        n_feat0= 48,
        feature_dim= [72,96,120],
        prompt_dim= [24,48,72],
        sens_n_feat0= 24,
        sens_feature_dim= [36,48,60],
        sens_prompt_dim= [12,24,36],
        len_prompt= [5,5,5],
        prompt_size= [64,32,16],
        n_enc_cab= [2,3,3],
        n_dec_cab= [2,3,3],
        n_skip_cab= [1,1,1],
        n_bottleneck_cab= 3,
        no_use_ca= False,
        learnable_prompt= False,
        adaptive_input= True,
        n_buffer= 6,
        n_history= 16,
        use_sens_adj= True,
)


    import pathlib
    pathlib.PosixPath = pathlib.WindowsPath

#    model_path = '/home/sbu/kian/PromptMR-plus-H100/exp/cmr24-cardiac/pmr-plus/deep_recon25_H100/hgpxcwxp/checkpoints/last.ckpt'
    model_path = '/mnt/nfs/kian2/exp/cmr24-cardiac/pmr-plus/deep_recon25_H100/2fmc2zsi/checkpoints/last.ckpt'
    state_dict = torch.load(model_path)['state_dict']
    state_dict.pop('loss.w')


    # Select the generator model of the Patch-Gan 
    state_dict = {k.replace('promptmr.', ''): v for k, v in state_dict.items()}
    model.load_state_dict(state_dict)
    model.eval()
    model.to('cuda:0')

    print("************************************************** MODEL IS LOADED **************************************************")

    
################################################################## MODEL ##################################################################



    # main function: reconstruct and save files
    torch.cuda.empty_cache()

    bs1 = 6#4
    predict(f_cine, model = model, bs1 = bs1, center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()

    bs1 = 5#6
    predict(f_mapping, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()

    bs1 = 5#7
    predict(f_t1rho, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()

    bs1 = 3#3
    predict(f_flow2d, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()

    bs1 = 3#8
    predict(f_blackblood, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()    

    bs1 = 6#9
    predict(f_lge, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()

    bs1 = 6#9
    predict(f_perfusion, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()

    bs1 = 6#9
    predict(f_t1w, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()

    bs1 = 6#9
    predict(f_t2w, model = model, bs1 = bs1,center_crop=center_crop, num_works=num_works, input_dir=input_dir, output_dir=output_dir)
    torch.cuda.empty_cache()



