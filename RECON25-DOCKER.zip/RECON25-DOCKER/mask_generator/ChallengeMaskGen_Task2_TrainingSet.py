

import os
import numpy as np
import scipy.io
from ktMaskGenerator_Task2 import ktMaskGenerator_Task2

def ChallengeMaskGen_Task2_TrainingSet(data_path, mainSavePath, pattern, R, file_nameID, dataName, setName):
    """
    Generate and save undersampling mask for Task 2 training set.

    Args:
        data_path (str): Path to .mat file containing 'kspace_full' variable (5D array).
        mainSavePath (str): Directory to save masks.
        pattern (str): Sampling pattern, e.g. 'ktUniform', 'ktGaussian', 'ktRadial'.
        R (float): Acceleration factor.
        file_nameID (str): Subfolder name under mainSavePath for saving.
        dataName (str): Base name for the saved mask file.
        setName (str): Should be 'TrainingSet' to save mask, else no saving.

    """
    # Load kspace data from MATLAB file
    data = scipy.io.loadmat(data_path)
    kspace_full = data['kspace_full']  # Expect shape: [nx, ny, sc, sz, t]

    nx = kspace_full.shape[0]
    ny = kspace_full.shape[1]
    nt = kspace_full.shape[4]
    ncalib = 16

    # Generate mask: shape [nx, ny, nt]
    mask = ktMaskGenerator_Task2(nx, ny, nt, ncalib, R, pattern)

    # Save mask if setName is 'TrainingSet'
    if setName == 'TrainingSet':
        savepath1 = os.path.join(mainSavePath, file_nameID)
        os.makedirs(savepath1, exist_ok=True)
        filename = f"{dataName}_mask_{pattern}{int(R)}.mat"
        save_filepath = os.path.join(savepath1, filename)
        scipy.io.savemat(save_filepath, {'mask': mask}, do_compression=True)

    # Optional visualization (commented out)
    # import matplotlib.pyplot as plt
    # plt.figure()
    # plt.imshow(mask, cmap='gray')
    # plt.title('Mask')
    # plt.show()

    # plt.figure()
    # plt.imshow(mask[60, :, :], cmap='gray')
    # plt.title('Mask slice at index 60')
    # plt.show()
