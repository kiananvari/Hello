import numpy as np

def ktdup(ph, ti, ny, nt):
    """
    Displaces duplicate samples in (ph, ti) to nearest vacant location on a ny-by-nt grid.
    
    Inputs:
        ph, ti: arrays of sample coordinates (can be negative or zero-centered)
        ny, nt: dimensions of the grid

    Outputs:
        ph, ti: adjusted arrays with no duplicates on the grid
    """

    # Shift coordinates to positive 1-based indexing
    ph = ph + int(np.ceil((ny + 1) / 2))
    ti = ti + int(np.ceil((nt + 1) / 2))

    pt = (ti - 1) * ny + ph  # linear indices (1-based)

    uniquept, counts = np.unique(pt, return_counts=True)
    repeated_values = uniquept[counts != 1]

    # Indices of duplicates (beyond first occurrence)
    dupind = []
    for val in repeated_values:
        locs = np.where(pt == val)[0]
        dupind.extend(locs[1:])  # keep first, add others

    dupind = np.array(dupind)

    # Vacant locations on the grid
    full_set = np.arange(1, ny * nt + 1)
    empind = np.setdiff1d(full_set, pt)

    # For each duplicate, assign nearest vacant index and update
    for i in dupind:
        newind = nearestvac(pt[i], empind, ny)
        pt[i] = newind
        empind = empind[empind != newind]

    # Convert linear indices back to (ph, ti)
    ph, ti = ind2xy(pt, ny)

    # Shift coordinates back
    ph = ph - int(np.ceil((ny + 1) / 2))
    ti = ti - int(np.ceil((nt + 1) / 2))

    return ph, ti


def nearestvac(dupind, empind, ny):
    """
    Find nearest vacant location to dupind among empind along phase-encoding direction only.
    """
    x0, y0 = ind2xy(np.array([dupind]), ny)
    x, y = ind2xy(empind, ny)

    dis1 = (x - x0) ** 2
    dis2 = (y - y0) ** 2
    # Enforce y-distance to be zero (only consider vacancies with same y)
    dis2[dis2 > np.finfo(float).eps] = np.inf
    dist = np.sqrt(dis1 + dis2)

    b = np.argmin(dist)
    return empind[b]


def ind2xy(ind, X):
    """
    Convert 1-based linear indices to (x,y) coordinates on a grid with width X.
    
    MATLAB: 
    x = ind - floor((ind-1)/X)*X;
    y = ceil(ind/X);

    Python uses zero-based indexing, but here we keep MATLAB's 1-based logic.
    """
    ind = np.array(ind)
    x = ind - ((ind - 1) // X) * X
    y = (ind + X - 1) // X  # ceil division for positive integers
    return x, y
