# import numpy as np
# from scipy.linalg import toeplitz

# from ktdup import ktdup
# from zpad import zpad

# def ktUniformSampling(nx, ny, nt, ncalib, R):
#     """
#     Generate the kt sampling index from Uniform distribution with autocalibration signals (ACS).

#     Parameters:
#     nx, ny, nt : int
#         Dimensions.
#     ncalib : int
#         Number of calibration lines in y.
#     R : float
#         Undersampling factor.

#     Returns:
#     mask : np.ndarray
#         Sampling mask of shape (nx, ny, nt).
#     """
#     ptmp = np.zeros(ny)
#     ptmp[np.round(np.arange(0, ny, R)).astype(int)] = 1

#     ttmp = np.zeros(nt)
#     ttmp[np.round(np.arange(0, nt, R)).astype(int)] = 1

#     Top = toeplitz(ptmp, ttmp)
#     ind = np.flatnonzero(Top)

#     ph = (ind % ny) - (ny // 2)
#     ti = (ind // ny) - (nt // 2)

#     # Assuming ktdup(ph, ti, ny, nt) returns updated ph and ti arrays
#     ph, ti = ktdup(ph, ti, ny, nt)

#     samp = np.zeros((ny, nt))
#     ind2 = np.round(ny * (ti + (nt // 2)) + (ph + (ny // 2))).astype(int)

#     # Correct indices out of range
#     ind2[ind2 < 0] = 0  # zero-based indexing in Python
#     ind2[ind2 >= ny*nt] = ny*nt - 1

#     samp_flat = samp.flatten()
#     samp_flat[ind2] = 1
#     samp = samp_flat.reshape(ny, nt)

#     acs = zpad(np.ones((nx, ncalib, nt)), [nx, ny, nt])
#     ktus = np.transpose(np.tile(samp, (nx, 1, 1)), (0, 1, 2))

#     mask_temp = ktus + acs
#     mask = (mask_temp > 0).astype(float)

#     return mask


import numpy as np
from scipy.linalg import toeplitz

from mask_generator.ktdup import ktdup
from mask_generator.zpad import zpad  # your exact zpad function


def ktUniformSampling(nx, ny, nt, ncalib, R):
    """
    Generate the kt sampling index from Uniform distribution with autocalibration signals (ACS).
    Supports odd dimensions without cropping by using provided zpad.

    Parameters:
    nx, ny, nt : int
        Dimensions.
    ncalib : int
        Number of calibration lines in y.
    R : float
        Undersampling factor.

    Returns:
    mask : np.ndarray
        Sampling mask of shape (nx, ny, nt).
    """

    # Create sampling pattern along y dimension
    p_indices = np.arange(0, ny, R)
    p_indices = np.clip(np.round(p_indices).astype(int), 0, ny - 1)  # clip indices to valid range
    ptmp = np.zeros(ny)
    ptmp[p_indices] = 1

    # Create sampling pattern along t dimension
    t_indices = np.arange(0, nt, R)
    t_indices = np.clip(np.round(t_indices).astype(int), 0, nt - 1)  # clip indices
    ttmp = np.zeros(nt)
    ttmp[t_indices] = 1

    # Toeplitz matrix to combine y and t sampling patterns
    Top = toeplitz(ptmp, ttmp)
    ind = np.flatnonzero(Top)

    ph = (ind % ny) - (ny // 2)
    ti = (ind // ny) - (nt // 2)

    # Duplicate indices using ktdup (assumed implemented)
    ph, ti = ktdup(ph, ti, ny, nt)

    samp = np.zeros((ny, nt))

    ind2 = np.round(ny * (ti + (nt // 2)) + (ph + (ny // 2))).astype(int)
    ind2 = np.clip(ind2, 0, ny * nt - 1)  # clip indices to avoid out-of-bounds

    samp_flat = samp.flatten()
    samp_flat[ind2] = 1
    samp = samp_flat.reshape(ny, nt)

    # Create ACS calibration lines, size (nx, ncalib, nt)
    acs_input = np.ones((nx, ncalib, nt), dtype=float)

    # Pad ACS to size (nx, ny, nt) centered using your zpad function
    acs = zpad(acs_input, [nx, ny, nt])

    # Tile sampling mask along nx dimension to match ACS shape
    ktus = np.tile(samp, (nx, 1, 1))

    # Combine undersampling mask and ACS mask
    mask_temp = ktus + acs
    mask = (mask_temp > 0).astype(float)

    return mask
