import numpy as np
from mask_generator.ktdup import ktdup
from mask_generator.zpad import zpad

def ktGaussianSampling(nx, ny, nt, ncalib, R, alpha=0.5, seed=None):
    if seed is not None:
        np.random.seed(seed)

    # Corrected phase encode indices centered around zero with length exactly ny
    p1 = np.arange(-(ny // 2), ny - (ny // 2))[:, None]

    tr = round(ny / R)  # number of samples per frame
    ti = []
    ph = []

    sig = ny / 5
    # Define sampling probability density (Gaussian-shaped)
    prob = 0.1 + (alpha / (1 - alpha + 1e-10)) * np.exp(-(p1 ** 2) / (2 * sig ** 2))
    prob = prob / np.sum(prob)

    for t in range(nt):
        # Sample phase-encoding positions for this time frame
        chosen_ph = np.random.choice(ny, tr, replace=False, p=prob.flatten())
        chosen_ph = np.sort(chosen_ph)

        ph.append(chosen_ph)
        ti.append(np.full_like(chosen_ph, t))

    ph = np.concatenate(ph)
    ti = np.concatenate(ti)

    # Center ph and ti around zero
    ph = ph - (ny // 2)
    ti = ti - (nt // 2)

    # Duplicate and correct using ktdup
    ph, ti = ktdup(ph, ti, ny, nt)

    # Convert to flat indices
    ind2 = np.round(ny * (ti + nt // 2) + (ph + ny // 2)).astype(int)
    ind2 = np.clip(ind2, 0, ny * nt - 1)

    # Create sampling mask
    samp_flat = np.zeros(ny * nt, dtype=float)
    samp_flat[ind2] = 1
    samp = samp_flat.reshape(ny, nt)

    # Create ACS region
    acs_input = np.ones((nx, ncalib, nt), dtype=float)
    acs = zpad(acs_input, [nx, ny, nt])

    # Expand sampling mask to full 3D mask
    mask_sampling = np.tile(samp[None, :, :], (nx, 1, 1))

    # Combine ACS and Gaussian undersampling mask
    mask = ((mask_sampling + acs) > 0).astype(float)

    return mask
