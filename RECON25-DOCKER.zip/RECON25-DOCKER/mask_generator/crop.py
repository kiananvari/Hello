import numpy as np

def crop(x, *sizes):
    """
    Crop an array around its center.

    Usage:
      crop(x, sx, sy)
      crop(x, sx, sy, sz)
      crop(x, [sx, sy, sz, st])

    Parameters:
    - x: np.ndarray, input array of dimension 2 to 4.
    - sizes: variable length size arguments (ints) or a single list/tuple with sizes.

    Returns:
    - cropped np.ndarray.
    """
    if len(sizes) == 0:
        raise ValueError('must have a target size')

    # If a single size list/tuple is passed, unpack it
    if len(sizes) == 1 and isinstance(sizes[0], (list, tuple, np.ndarray)):
        s = list(sizes[0])
    else:
        s = list(sizes)

    m = list(x.shape)
    
    # Pad s with ones if shorter than dimensions of x
    if len(s) < len(m):
        s.extend([1] * (len(m) - len(s)))

    # If sizes equal to input dimensions, return original array
    if all(m[i] == s[i] for i in range(len(m))):
        return x

    # Calculate indices for each dimension
    idx = []
    for dim in range(len(s)):
        center = m[dim] // 2
        start = center - (s[dim] // 2)
        end = start + s[dim]
        idx.append(slice(start, end))

    # Crop using slices
    res = x[tuple(idx)]
    return res
