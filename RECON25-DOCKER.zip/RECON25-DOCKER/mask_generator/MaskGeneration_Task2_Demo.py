import os
import numpy as np
import matplotlib.pyplot as plt
from ktMaskGenerator import ktMaskGenerator_Task2

def MaskGeneration_Task2_Demo():
    """
    Demo script for mask generation in Task 2 (CMRxRecon MICCAI2024).

    Author: Zi Wang (wangzi1023@stu.xmu.edu.cn; wangziblake@gmail.com)
    March 31, 2024

    If you want to use the code, please cite:
    Zi Wang et al., Deep Separable Spatiotemporal Learning for Fast Dynamic Cardiac MRI, arXiv:2402.15939, 2024.
    """
    # Clear previous variables or warnings not needed in Python
    
    # Add current directory and subdirectories to path
    # (In Python, typically you organize imports differently, so no need for addpath)
    
    # Define acceleration factors
    for R in [4, 8, 12, 16, 20, 24]:
        # Simulate 5D kspace: [kx, ky, sc, sz, t]
        kspace = np.ones((300, 128, 10, 1, 6))

        # kspace = np.ones((400, 246, 10, 1, 5))

        nx = kspace.shape[0]
        ny = kspace.shape[1]
        nt = kspace.shape[4]
        ncalib = 16
        pattern = 'ktRadial'  # options: 'ktUniform', 'ktGaussian', 'ktRadial'
        
        # Generate mask [kx, ky, t]
        mask = ktMaskGenerator_Task2(nx, ny, nt, ncalib, R, pattern)
        
        mask = mask[:, :, :-1]

        # # Save mask to .mat file using scipy.io.savemat
        # import scipy.io
        # filename = f"{pattern}_R{R}.mat"
        # scipy.io.savemat(filename, {'mask': mask}, do_compression=True)
        
        # Combined plot: all temporal frames + x=60 slice
        nt_mask = mask.shape[2]

        fig, axs = plt.subplots(2, nt_mask, figsize=(4 * nt_mask, 8))

        # First row: temporal frames
        for t in range(nt_mask):
            ax = axs[0, t] if nt_mask > 1 else axs[0]
            ax.imshow(mask[:, :, t], cmap='gray')
            ax.set_title(f't = {t}')
            ax.axis('off')

        # Second row: x=60 slice across time
        for t in range(nt_mask):
            ax = axs[1, t] if nt_mask > 1 else axs[1]
            ax.imshow(mask[60, :, t][None, :], cmap='gray', aspect='auto')
            ax.set_title(f'x=60, t = {t}')
            ax.axis('off')

        plt.suptitle(f'CMRxRecon2024 Mask Visualization (R={R})', fontsize=16)
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.show()


# Note: The function ktMaskGenerator_Task2 must be implemented in Python,
# matching the MATLAB version for this to work.

MaskGeneration_Task2_Demo()