import os
import h5py
import matplotlib.pyplot as plt
import numpy as np
from ktMaskGenerator_Task import ktMaskGenerator_Task

# Replace this with your actual path
h5_dataset_path = 'h5_dataset'

# List all .h5 files in the folder
h5_files = [f for f in os.listdir(h5_dataset_path) if f.endswith('.h5')]

for file_name in h5_files:
    file_path = os.path.join(h5_dataset_path, file_name)
    try:
        with h5py.File(file_path, 'r') as hf:
            if 'kspace' not in hf:
                print(f"{file_name}: 'kspace' key not found.")
                continue

            kspace_dset = hf['kspace']
            original_shape = kspace_dset.shape
            ndim = len(original_shape)

            if ndim == 5:
                # Lazy load and transpose using moveaxis (more readable and sometimes faster)
                kspace = np.moveaxis(kspace_dset, [0, 1, 2, 3, 4], [4, 3, 2, 1, 0])
            elif ndim == 4:
                kspace = np.moveaxis(kspace_dset, [0, 1, 2, 3], [3, 2, 1, 0])
            else:
                print(f"{file_name}: unsupported kspace dimension {ndim}")
                continue

            print(f"{file_name}: kspace shape after permutation {kspace.shape}")

            # Simulated kspace overwrite (replace with your actual data logic)
            kspace = np.ones((kspace.shape[0], kspace.shape[1], 10, 1, 6), dtype=np.complex64)

            # Mask generation dimensions
            nx, ny, _, _, nt = kspace.shape

            ncalib = 16
            pattern = 'ktRadial'

            try:
                mask = ktMaskGenerator_Task2(nx, ny, nt, ncalib, 4, pattern)
                print(f"{file_name}: mask CREATED")
            except Exception as mask_err:
                print(f"{file_name}: ERROR during mask generation with shape ({nx}, {ny}, {nt}) - {mask_err}")

            mask = mask[:, :, :-1]

            # # Save mask to .mat file using scipy.io.savemat
            # import scipy.io
            # filename = f"{pattern}_R{R}.mat"
            # scipy.io.savemat(filename, {'mask': mask}, do_compression=True)
            
            # Combined plot: all temporal frames + x=60 slice
            nt_mask = mask.shape[2]

            fig, axs = plt.subplots(2, nt_mask, figsize=(4 * nt_mask, 8))

            # First row: temporal frames
            for t in range(nt_mask):
                ax = axs[0, t] if nt_mask > 1 else axs[0]
                ax.imshow(mask[:, :, t], cmap='gray')
                ax.set_title(f't = {t}')
                ax.axis('off')

            # Second row: x=60 slice across time
            for t in range(nt_mask):
                ax = axs[1, t] if nt_mask > 1 else axs[1]
                ax.imshow(mask[60, :, t][None, :], cmap='gray', aspect='auto')
                ax.set_title(f'x=60, t = {t}')
                ax.axis('off')

            plt.suptitle(f'CMRxRecon2024 Mask Visualization (R={4})', fontsize=16)
            plt.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.show()    

    except Exception as e:
        print(f"{file_name}: ERROR opening file - {e}")
