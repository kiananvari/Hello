import numpy as np

def randp(P, sd, *args):
    """
    RANDP - pick random values with relative probability
    
    R = randp(P, sd, *args) returns integers in the range from 1 to
    len(P) with relative probabilities proportional to P.
    
    P : 1D array-like of probabilities (non-negative)
    sd : int, random seed
    *args : dimensions or shape tuple for output size
    
    Examples:
        R = randp([1, 3, 2], 1, 10000)
        # returns a 1x10000 vector with approx 1/6, 3/6, 2/6 proportions
    
        R = randp([1, 1, 0, 0, 1], 10, 10, 1)
        # returns 10x1 vector sampled from [1, 2, 5]
    """
    P = np.asarray(P).flatten()
    if np.any(P < 0):
        raise ValueError("All probabilities should be 0 or larger.")
    
    if P.size == 0 or np.sum(P) == 0:
        # All zero probabilities: return zeros of requested shape
        if len(args) == 1 and isinstance(args[0], (tuple, list, np.ndarray)):
            shape = tuple(args[0])
        elif len(args) > 0:
            shape = args
        else:
            shape = (1,)
        return np.zeros(shape, dtype=int)
    
    # Set random seed
    rng = np.random.default_rng(sd)
    
    # Determine output shape
    if len(args) == 1 and isinstance(args[0], (tuple, list, np.ndarray)):
        shape = tuple(args[0])
    elif len(args) > 0:
        shape = args
    else:
        shape = (1,)
    
    # Normalize probabilities
    cdf = np.cumsum(P) / np.sum(P)
    
    # Generate uniform random values
    uniform_samples = rng.random(np.prod(shape))
    
    # Use searchsorted to find the index for each random number in cdf
    indices = np.searchsorted(cdf, uniform_samples) + 1  # +1 for 1-based indexing
    
    # Reshape to desired output shape
    return indices.reshape(shape)
