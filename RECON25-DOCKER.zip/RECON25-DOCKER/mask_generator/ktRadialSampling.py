import numpy as np
from scipy.ndimage import rotate
from mask_generator.ktdup import ktdup
from mask_generator.zpad import zpad

def ktRadialSampling(nx, ny, nt, ncalib, R, angle4next, cropcorner):
    """
    Generate the kt sampling index from Pseudo-Radial distribution with autocalibration signals (ACS).

    Parameters:
    nx, ny, nt : int
        Dimensions.
    ncalib : int
        Number of calibration lines in x and y.
    R : float
        Undersampling factor.
    angle4next : float
        Angle offset for next time frame.
    cropcorner : bool
        Whether to crop corners or not.

    Returns:
    mask : np.ndarray
        Sampling mask of shape (nx, ny, nt).
    """
    rate = 1 / R
    beams = int(np.floor(rate * 180))  # number of angles
    
    if cropcorner:
        a = max(nx, ny)
    else:
        a = int(np.ceil(np.sqrt(2) * max(nx, ny)))

    aux = np.zeros((a, a))
    aux[a // 2, :] = 1  # center row set to 1

    angle = 180 / beams

    ktus = np.zeros((nx, ny, nt))
    
    for i in range(nt):
        start_angle = angle4next * i
        angles = np.arange(start_angle, 180 + start_angle, angle)
        image = np.zeros((nx, ny))

        for ang in angles:
            # Rotate aux by ang degrees, keep same size, crop to nx, ny
            temp = rotate(aux, ang, reshape=False, order=1, mode='constant', cval=0)
            temp_cropped = crop(temp, nx, ny)
            image += temp_cropped
        
        ktus[:, :, i] = image

    acs = zpad(np.ones((ncalib, ncalib, nt)), [nx, ny, nt])
    mask_temp = ktus + acs
    mask = (mask_temp > 0).astype(float)
    return mask

def crop(image, nx, ny):
    """
    Crop the image to size (nx, ny) from the center.
    """
    x_center = image.shape[0] // 2
    y_center = image.shape[1] // 2

    x_start = x_center - nx // 2
    y_start = y_center - ny // 2

    return image[x_start:x_start + nx, y_start:y_start + ny]
