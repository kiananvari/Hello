import numpy as np

def zpad(x, *args):
    """
    Zero pads an array x to target size s = (sx, sy, sz, ...) around its center.
    Works for any ndim, supports odd and even dims without size mismatch.

    Parameters:
    x : np.ndarray
        Input array.
    sx, sy, sz, ... : int or list/tuple of ints
        Target size dimensions.

    Returns:
    res : np.ndarray
        Zero-padded array of shape s.
    """
    if len(args) == 0:
        raise ValueError('Must specify target size dimensions.')

    if len(args) == 1:
        if isinstance(args[0], (list, tuple, np.ndarray)):
            s = list(args[0])
        else:
            s = [args[0]]
    else:
        s = list(args)

    m = list(x.shape)
    # If input has fewer dims, pad its shape with ones
    if len(m) < len(s):
        m += [1] * (len(s) - len(m))

    # If already target size, return x as is
    if all(m_i == s_i for m_i, s_i in zip(m, s)):
        return x

    res = np.zeros(s, dtype=x.dtype)

    idx = []
    for dim in range(len(s)):
        total_pad = s[dim] - m[dim]
        if total_pad < 0:
            raise ValueError(f"Target size {s} must be >= input size {m} in every dimension.")

        pad_before = total_pad // 2
        pad_after = total_pad - pad_before

        start = pad_before
        end = pad_before + m[dim]

        idx.append(slice(start, end))

    res[tuple(idx)] = x
    return res
