import numpy as np
from mask_generator.ktRadialSampling import ktRadialSampling
from mask_generator.ktGaussianSampling import ktGaussianSampling
from mask_generator.ktUniformSampling import ktUniformSampling
import torch

def ktMaskGenerator(nx, ny, nt, ncalib, R, pattern):
    """
    Generate undersampling mask for Task 2.
    
    Args:
        nx, ny, nt: Dimensions of k-t space
        ncalib: Number of autocalibration lines
        R: Acceleration factor
        pattern: Sampling pattern, one of ['ktUniform', 'ktGaussian', 'ktRadial']
    
    Returns:
        mask: Sampling mask array of shape (nx, ny, nt)
    """
    
    if pattern == 'kt_uniform':
        mask = ktUniformSampling(nx, ny, nt, ncalib, R)
        # realAF = mask.size / np.sum(mask)
        # print(f"Real acceleration factor: {realAF:.2f}")
    elif pattern == 'kt_random':
        alpha = 0.2  # Controls sampling density (0: uniform, 1: max non-uniform)
        seed = np.random.randint(1, 1001)  # Random seed in [1,1000]
        mask = ktGaussianSampling(nx, ny, nt, ncalib, R, alpha, seed)
        # realAF = mask.size / np.sum(mask)
        # print(f"Real acceleration factor: {realAF:.2f}")
    elif pattern == 'kt_radial':
        angle4next = 137.5  # Golden angle in degrees for rotating sampling lines
        cropcorner = True
        R = R * 0.6  # Adjust acceleration factor for radial pattern
        mask = ktRadialSampling(nx, ny, nt, ncalib, R, angle4next, cropcorner)
        # realAF = mask.size / np.sum(mask)
        # print(f"Real acceleration factor: {realAF:.2f}")
    else:
        raise ValueError("No selected undersampling pattern. Please choose a valid one.")
    
    mask = mask[:, :, :-1]

    # Assuming k_space is a NumPy array with shape (442, 198, 5)
    mask = np.transpose(mask, (2, 0, 1))  # Now shape is (5, 442, 198)
    mask = np.expand_dims(mask, axis=-1).astype(np.float32)  # Now shape is (5, 442, 198, 1)

    # Convert mask to torch.Tensor
    mask = torch.from_numpy(mask)
    return mask, ncalib
